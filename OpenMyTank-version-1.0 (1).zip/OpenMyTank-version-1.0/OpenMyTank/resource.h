//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by my_tank.rc
//
#define IDI_FAVICON                     131
#define IDR_BEEPWAVE                    132
#define ID_GENERAL_SETTINGS_PAGE        134
#define ID_SCREENSHOT_SETTINGS_PAGE     136
#define ID_INTERFACE_SETTINGS_PAGE      137
#define ID_CHAT_SETTINGS_PAGE           138

#define IDS_LANGUAGE                    300
#define IDS_VERSION                     301
#define IDS_AUTHOR                      302
#define IDS_SETTINGS_TITLE              303
#define IDS_SETTINGS_BUTTON             304
#define IDS_LEFT_CLICKER_BUTTON         307
#define IDS_RIGHT_CLICKER_BUTTON        308
#define IDS_GET_URL_BUTTON              309
#define IDS_OPEN_URL_BUTTON             310
#define IDS_CLICKING_BUTTON             311
#define IDS_SCREENSHOT_PATH             312
#define IDS_SCREENSHOT_DIR              313
#define IDS_NEWS                        314
#define IDS_F1_MESSAGE                  315
#define IDS_F2_MESSAGE                  316
#define IDS_F3_MESSAGE                  317
#define IDS_F4_MESSAGE                  318
#define IDS_F5_MESSAGE                  319
#define IDS_F6_MESSAGE                  320
#define IDS_F7_MESSAGE                  321
#define IDS_F8_MESSAGE                  322
#define IDS_F9_MESSAGE                  323
#define IDS_F10_MESSAGE                 324
#define IDS_HELP_PAGE_BUTTON            325
#define IDS_BATTLE_IS_LOADED            326
#define IDS_LINGUALEO                   327

#define IDC_VERSIONS                    1002
#define ID_RESETSETTINGSBUTTON          1006
#define IDC_CLICKERS_DELAY_EDIT         1010
#define IDC_ENGLISH                     1011
#define IDC_GERMAN                      1012
#define IDC_RUSSIAN                     1013
#define IDC_PATH_EDIT                   1014
#define IDC_PATH_BUTTON                 1015
#define IDC_DD_MM_YYYY                  1016
#define IDC_YYYY_MM_DD                  1017
#define IDC_JPEG                        1018
#define IDC_PNG                         1019
#define IDC_BMP                         1020
#define IDC_QUALITY_EDIT                1021
#define IDC_BEEP_CHECKBOX               1022
#define IDC_KEY_PRTSC                   1023
#define IDC_KEY_TILDE                   1024
#define IDC_KEY_ESC                     1025
#define IDC_SERVERBUTTONS_EDIT          1027

#define IDC_CHAT_EDIT1                  1100
#define IDC_CHAT_CHECK1                 1101
#define IDC_CHAT_EDIT2                  1102
#define IDC_CHAT_CHECK2                 1103
#define IDC_CHAT_EDIT3                  1104
#define IDC_CHAT_CHECK3                 1105
#define IDC_CHAT_EDIT4                  1106
#define IDC_CHAT_CHECK4                 1107
#define IDC_CHAT_EDIT5                  1108
#define IDC_CHAT_CHECK5                 1109
#define IDC_CHAT_EDIT6                  1110
#define IDC_CHAT_CHECK6                 1111
#define IDC_CHAT_EDIT7                  1112
#define IDC_CHAT_CHECK7                 1113
#define IDC_CHAT_EDIT8                  1114
#define IDC_CHAT_CHECK8                 1115
#define IDC_CHAT_EDIT9                  1116
#define IDC_CHAT_CHECK9                 1117
#define IDC_CHAT_EDIT10                 1118
#define IDC_CHAT_CHECK10                1119

#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1028
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
